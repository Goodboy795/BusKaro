$java = "C:\Program Files\Eclipse Adoptium\jdk-17.0.18.8-hotspot"
$maven = "C:\Users\user\Desktop\buskaro\samplepro\BusKaro-main\backend\apache-maven-3.9.6"
[Environment]::SetEnvironmentVariable("JAVA_HOME", $java, "User")
[Environment]::SetEnvironmentVariable("MAVEN_HOME", $maven, "User")
$uPath = [Environment]::GetEnvironmentVariable("PATH", "User")
if ($uPath -notlike "*" + $maven + "\\bin*") {
    [Environment]::SetEnvironmentVariable("PATH", $uPath + ";" + $maven + "\\bin", "User")
}
Write-Host "SET_OK"
Write-Host "JAVA_HOME=" + [Environment]::GetEnvironmentVariable("JAVA_HOME", "User")
Write-Host "MAVEN_HOME=" + [Environment]::GetEnvironmentVariable("MAVEN_HOME", "User")
$userPath = [Environment]::GetEnvironmentVariable("PATH", "User")
Write-Host "PATH_LAST=" + $userPath.Split(";")[-1]