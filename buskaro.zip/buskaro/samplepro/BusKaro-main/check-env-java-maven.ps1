Write-Host [Environment]::GetEnvironmentVariable('JAVA_HOME','User')
Write-Host [Environment]::GetEnvironmentVariable('MAVEN_HOME','User')
$p = [Environment]::GetEnvironmentVariable('PATH','User')
Write-Host $p.Split(';')[-1]